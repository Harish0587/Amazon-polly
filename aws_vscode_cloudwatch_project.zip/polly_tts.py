import boto3

def generate_tts(text, file):
    polly = boto3.client("polly", region_name="ap-south-1")
    resp = polly.synthesize_speech(Text=text, OutputFormat="mp3", VoiceId="Joanna")
    with open(file,"wb") as f:
        f.write(resp["AudioStream"].read())
    print("Generated:", file)

if __name__=="__main__":
    generate_tts("VS Code CloudWatch Project", "output.mp3")
