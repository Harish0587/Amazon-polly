# VS Code AWS Project with CloudWatch

Includes:
- S3 creation script
- Lambda function with CloudWatch logs
- Polly TTS script

Use VS Code terminal to run Python files.
CloudWatch logs appear under /aws/lambda/<lambda_name>.
