import json
import boto3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info("Lambda started")
    logger.info(f"Event received: {event}")

    polly = boto3.client("polly")
    response = polly.synthesize_speech(
        Text="CloudWatch log test from Lambda",
        OutputFormat="mp3",
        VoiceId="Joanna"
    )

    logger.info("Polly synthesis done")
    return {"statusCode":200,"body":"Lambda executed with CloudWatch logs"}
