import boto3

def polly_text_to_speech(text, output_file):
    polly = boto3.client("polly", region_name="ap-south-1")

    response = polly.synthesize_speech(
        Text=text,
        OutputFormat="mp3",
        VoiceId="Joanna"
    )

    with open(output_file, "wb") as f:
        f.write(response["AudioStream"].read())

    print("Generated:", output_file)

if __name__ == "__main__":
    polly_text_to_speech("Hello Harish, from Polly!", "output.mp3")
