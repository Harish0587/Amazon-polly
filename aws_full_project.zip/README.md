# AWS Project

Includes:
- Amazon S3 bucket creation script
- AWS Lambda function
- Amazon Polly Text-to-Speech script

Run using VS Code terminal.
