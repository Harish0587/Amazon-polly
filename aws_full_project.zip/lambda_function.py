import json
import boto3

def lambda_handler(event, context):
    text = event.get("text", "Hello from Lambda")
    polly = boto3.client("polly")

    response = polly.synthesize_speech(
        Text=text,
        OutputFormat="mp3",
        VoiceId="Joanna"
    )

    return {
        "statusCode": 200,
        "body": "Polly synthesis complete."
    }
